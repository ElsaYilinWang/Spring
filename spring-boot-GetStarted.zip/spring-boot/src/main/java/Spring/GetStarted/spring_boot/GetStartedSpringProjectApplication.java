package Spring.GetStarted.spring_boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GetStartedSpringProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(GetStartedSpringProjectApplication.class, args);
	}

}
